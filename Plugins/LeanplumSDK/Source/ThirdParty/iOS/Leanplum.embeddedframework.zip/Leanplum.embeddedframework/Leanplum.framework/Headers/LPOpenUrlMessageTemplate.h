//
//  LPOpenUrlMessageTemplate.h
//  Leanplum-iOS-SDK
//
//  Created by Mayank Sanganeria on 2/6/20.
//

#import "LPMessageTemplateProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface LPOpenUrlMessageTemplate : NSObject <LPMessageTemplateProtocol>

@end

NS_ASSUME_NONNULL_END
